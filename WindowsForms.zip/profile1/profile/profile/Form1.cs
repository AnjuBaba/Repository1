﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace profile
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        SqlConnection con;
        SqlCommand cmd;
        SqlDataReader rdr;

        private void exitBTN_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            con = new SqlConnection("server=BLT210\\SQLEXPRESS; Database = profile; Integrated Security=true ");
            con.Open();
            
        }

        private void newBTN_Click(object sender, EventArgs e)
        {
            stuno.Text = "";
            nameTXT.Text = "";
            courceTXT.Text = "";
            feesTXT.Text = "";
        }

        private void insertBTN_Click(object sender, EventArgs e)
        {
            if (stuno.Text == "")
            {
                MessageBox.Show("Please Enter Student ID", "Required");

            }

            if (string.IsNullOrWhiteSpace(stuno.Text))
            {

                stuno.Focus();
                id_error.SetError(stuno, "StudentId Required!");
            }
            else
            {

                id_error.SetError(stuno, "");
            }

            if (string.IsNullOrWhiteSpace(nameTXT.Text))
            {
                nameTXT.Focus();
                name_error.SetError(nameTXT, "Student Name Required!");
            }
            else
            {
                name_error.SetError(nameTXT, "");
            }

            string query;
            query = "INSERT into student_profile VALUES ('" + stuno.Text + "','" + nameTXT.Text + "','" + courceTXT.Text + "','" + feesTXT.Text + "','')";

            cmd = new SqlCommand(query, con);
            cmd.ExecuteNonQuery();
            MessageBox.Show("Inserted", "Done");
            stuno.Text = "";
            nameTXT.Text = "";
            courceTXT.Text = "";
            feesTXT.Text = "";
        }

        private void deleteBTN_Click(object sender, EventArgs e)
        {
            string query;
            query = "DELETE FROM student_profile WHERE student_id = '"+ stuno.Text + "'  ";

            cmd = new SqlCommand(query, con);
            cmd.ExecuteNonQuery();
            MessageBox.Show("Deleted Successfully", "Done");
            stuno.Text = "";         
        }

        private void updateBTN_Click(object sender, EventArgs e)
        {
            string query;
            query = "UPDATE student_profile set student_name='" + nameTXT.Text + "',course='" + courceTXT.Text + "',course_fee='" + feesTXT.Text + "' WHERE student_id ='" + stuno.Text + "' ";

            cmd = new SqlCommand(query, con);
            cmd.ExecuteNonQuery();


            MessageBox.Show("Updated Success", "Done");
            stuno.Text = "";
            nameTXT.Text = "";
            courceTXT.Text = "";
            feesTXT.Text = "";
        }

        private void searchBTN_Click(object sender, EventArgs e)
        {
            string query;
            query = "SELECT * FROM student_profile where student_id = '"+ stuno.Text +"'  ";

            cmd = new SqlCommand(query, con);
           
            try 
            {
                rdr = cmd.ExecuteReader();
                if (rdr.Read())
                {
                    stuno.Text = rdr[0].ToString();
                    nameTXT.Text = rdr[1].ToString();
                    courceTXT.Text = rdr[2].ToString();
                    feesTXT.Text = rdr[3].ToString();
                }
                else
                {
                    MessageBox.Show("Record NOt Match");
                }
                rdr.Close();
            }
            catch(Exception)
            {
                MessageBox.Show("Invald");
            }

        }

        private void fullbackBTN_Click(object sender, EventArgs e)
        {
            string query;
            query = "SELECT * FROM student_profile   ";

            cmd = new SqlCommand(query, con);

            try
            {
                rdr = cmd.ExecuteReader();
                if (rdr.Read())
                {
                    stuno.Text = rdr[0].ToString();
                    nameTXT.Text = rdr[1].ToString();
                    courceTXT.Text = rdr[2].ToString();
                    feesTXT.Text = rdr[3].ToString();
                }
                else
                {
                    MessageBox.Show("Record NOt Match");
                }
                rdr.Close();
            }
            catch (Exception)
            {
                MessageBox.Show("Invald");
            }
        }

        private void fullforwardBTN_Click(object sender, EventArgs e)
        {
            string query;
            query = "SELECT * FROM student_profile WHERE student_id=(SELECT MAX(student_id) FROM student_profile  )  ";

            cmd = new SqlCommand(query, con);

            try
            {
                rdr = cmd.ExecuteReader();
                if (rdr.Read())
                {
                    stuno.Text = rdr[0].ToString();
                    nameTXT.Text = rdr[1].ToString();
                    courceTXT.Text = rdr[2].ToString();
                    feesTXT.Text = rdr[3].ToString();
                }
                else
                {
                    MessageBox.Show("Record NOt Match");
                }
                rdr.Close();
            }
            catch (Exception)
            {
                MessageBox.Show("Invald");
            }
        }

        private void singlebackBTN_Click(object sender, EventArgs e)
        {

            int temp = Convert.ToInt32(stuno.Text) ;
            int oneback = (temp - 1);

            string query;
            query = "SELECT * FROM student_profile WHERE student_id='"+ oneback + "'  ";

            cmd = new SqlCommand(query, con);

            try
            {
                rdr = cmd.ExecuteReader();
                if (rdr.Read())
                {
                    stuno.Text = rdr[0].ToString();
                    nameTXT.Text = rdr[1].ToString();
                    courceTXT.Text = rdr[2].ToString();
                    feesTXT.Text = rdr[3].ToString();
                }
                else
                {
                    MessageBox.Show("Record NOt Match");
                }
                rdr.Close();
            }
            catch (Exception)
            {
                MessageBox.Show("Invald");
            }
        }

        private void singleforwardBTN_Click(object sender, EventArgs e)
        {
            int temp = Convert.ToInt32(stuno.Text);
            int oneforward = (temp + 1);

            string query;
            query = "SELECT * FROM student_profile WHERE student_id='" + oneforward + "'  ";

            cmd = new SqlCommand(query, con);

            try
            {
                rdr = cmd.ExecuteReader();
                if (rdr.Read())
                {
                    stuno.Text = rdr[0].ToString();
                    nameTXT.Text = rdr[1].ToString();
                    courceTXT.Text = rdr[2].ToString();
                    feesTXT.Text = rdr[3].ToString();
                }
                else
                {
                    MessageBox.Show("Record NOt Match");
                }
                rdr.Close();
            }
            catch (Exception)
            {
                MessageBox.Show("Invald");
            }
        }
    }
}
