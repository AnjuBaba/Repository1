﻿namespace profile
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.lb1 = new System.Windows.Forms.Label();
            this.lb2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.stuno = new System.Windows.Forms.TextBox();
            this.nameTXT = new System.Windows.Forms.TextBox();
            this.courceTXT = new System.Windows.Forms.TextBox();
            this.feesTXT = new System.Windows.Forms.TextBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.browseBTN = new System.Windows.Forms.Button();
            this.newBTN = new System.Windows.Forms.Button();
            this.insertBTN = new System.Windows.Forms.Button();
            this.searchBTN = new System.Windows.Forms.Button();
            this.updateBTN = new System.Windows.Forms.Button();
            this.deleteBTN = new System.Windows.Forms.Button();
            this.exitBTN = new System.Windows.Forms.Button();
            this.fullbackBTN = new System.Windows.Forms.Button();
            this.singlebackBTN = new System.Windows.Forms.Button();
            this.singleforwardBTN = new System.Windows.Forms.Button();
            this.fullforwardBTN = new System.Windows.Forms.Button();
            this.id_error = new System.Windows.Forms.ErrorProvider(this.components);
            this.name_error = new System.Windows.Forms.ErrorProvider(this.components);
            this.imageNAMETXT = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.id_error)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.name_error)).BeginInit();
            this.SuspendLayout();
            // 
            // lb1
            // 
            this.lb1.AutoSize = true;
            this.lb1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb1.Location = new System.Drawing.Point(24, 21);
            this.lb1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lb1.Name = "lb1";
            this.lb1.Size = new System.Drawing.Size(129, 20);
            this.lb1.TabIndex = 0;
            this.lb1.Text = "Student Profile";
            // 
            // lb2
            // 
            this.lb2.AutoSize = true;
            this.lb2.Location = new System.Drawing.Point(59, 56);
            this.lb2.Name = "lb2";
            this.lb2.Size = new System.Drawing.Size(92, 16);
            this.lb2.TabIndex = 1;
            this.lb2.Text = "Student No :";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(59, 89);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(113, 16);
            this.label1.TabIndex = 2;
            this.label1.Text = "Student Name :";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(59, 124);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(65, 16);
            this.label2.TabIndex = 3;
            this.label2.Text = "Course :";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(59, 164);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(104, 16);
            this.label3.TabIndex = 4;
            this.label3.Text = "Course Fees :";
            // 
            // stuno
            // 
            this.stuno.Location = new System.Drawing.Point(205, 53);
            this.stuno.Name = "stuno";
            this.stuno.Size = new System.Drawing.Size(84, 22);
            this.stuno.TabIndex = 5;
            // 
            // nameTXT
            // 
            this.nameTXT.Location = new System.Drawing.Point(205, 89);
            this.nameTXT.Name = "nameTXT";
            this.nameTXT.Size = new System.Drawing.Size(234, 22);
            this.nameTXT.TabIndex = 6;
            // 
            // courceTXT
            // 
            this.courceTXT.Location = new System.Drawing.Point(205, 124);
            this.courceTXT.Name = "courceTXT";
            this.courceTXT.Size = new System.Drawing.Size(234, 22);
            this.courceTXT.TabIndex = 7;
            // 
            // feesTXT
            // 
            this.feesTXT.Location = new System.Drawing.Point(205, 159);
            this.feesTXT.Name = "feesTXT";
            this.feesTXT.Size = new System.Drawing.Size(234, 22);
            this.feesTXT.TabIndex = 8;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Location = new System.Drawing.Point(476, 53);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(184, 127);
            this.pictureBox1.TabIndex = 9;
            this.pictureBox1.TabStop = false;
            // 
            // browseBTN
            // 
            this.browseBTN.Location = new System.Drawing.Point(585, 196);
            this.browseBTN.Name = "browseBTN";
            this.browseBTN.Size = new System.Drawing.Size(75, 23);
            this.browseBTN.TabIndex = 10;
            this.browseBTN.Text = "Browse";
            this.browseBTN.UseVisualStyleBackColor = true;
            this.browseBTN.Click += new System.EventHandler(this.browseBTN_Click);
            // 
            // newBTN
            // 
            this.newBTN.Location = new System.Drawing.Point(48, 287);
            this.newBTN.Name = "newBTN";
            this.newBTN.Size = new System.Drawing.Size(75, 23);
            this.newBTN.TabIndex = 11;
            this.newBTN.Text = "New";
            this.newBTN.UseVisualStyleBackColor = true;
            this.newBTN.Click += new System.EventHandler(this.newBTN_Click);
            // 
            // insertBTN
            // 
            this.insertBTN.Location = new System.Drawing.Point(151, 287);
            this.insertBTN.Name = "insertBTN";
            this.insertBTN.Size = new System.Drawing.Size(75, 23);
            this.insertBTN.TabIndex = 12;
            this.insertBTN.Text = "Insert";
            this.insertBTN.UseVisualStyleBackColor = true;
            this.insertBTN.Click += new System.EventHandler(this.insertBTN_Click);
            // 
            // searchBTN
            // 
            this.searchBTN.Location = new System.Drawing.Point(255, 287);
            this.searchBTN.Name = "searchBTN";
            this.searchBTN.Size = new System.Drawing.Size(75, 23);
            this.searchBTN.TabIndex = 13;
            this.searchBTN.Text = "Search";
            this.searchBTN.UseVisualStyleBackColor = true;
            this.searchBTN.Click += new System.EventHandler(this.searchBTN_Click);
            // 
            // updateBTN
            // 
            this.updateBTN.Location = new System.Drawing.Point(362, 287);
            this.updateBTN.Name = "updateBTN";
            this.updateBTN.Size = new System.Drawing.Size(75, 23);
            this.updateBTN.TabIndex = 14;
            this.updateBTN.Text = "Update";
            this.updateBTN.UseVisualStyleBackColor = true;
            this.updateBTN.Click += new System.EventHandler(this.updateBTN_Click);
            // 
            // deleteBTN
            // 
            this.deleteBTN.Location = new System.Drawing.Point(468, 287);
            this.deleteBTN.Name = "deleteBTN";
            this.deleteBTN.Size = new System.Drawing.Size(75, 23);
            this.deleteBTN.TabIndex = 15;
            this.deleteBTN.Text = "Delete";
            this.deleteBTN.UseVisualStyleBackColor = true;
            this.deleteBTN.Click += new System.EventHandler(this.deleteBTN_Click);
            // 
            // exitBTN
            // 
            this.exitBTN.Location = new System.Drawing.Point(573, 287);
            this.exitBTN.Name = "exitBTN";
            this.exitBTN.Size = new System.Drawing.Size(75, 23);
            this.exitBTN.TabIndex = 16;
            this.exitBTN.Text = "Exit";
            this.exitBTN.UseVisualStyleBackColor = true;
            this.exitBTN.Click += new System.EventHandler(this.exitBTN_Click);
            // 
            // fullbackBTN
            // 
            this.fullbackBTN.Location = new System.Drawing.Point(135, 239);
            this.fullbackBTN.Name = "fullbackBTN";
            this.fullbackBTN.Size = new System.Drawing.Size(75, 23);
            this.fullbackBTN.TabIndex = 17;
            this.fullbackBTN.Text = "|<<";
            this.fullbackBTN.UseVisualStyleBackColor = true;
            this.fullbackBTN.Click += new System.EventHandler(this.fullbackBTN_Click);
            // 
            // singlebackBTN
            // 
            this.singlebackBTN.Location = new System.Drawing.Point(252, 239);
            this.singlebackBTN.Name = "singlebackBTN";
            this.singlebackBTN.Size = new System.Drawing.Size(75, 23);
            this.singlebackBTN.TabIndex = 18;
            this.singlebackBTN.Text = "<<";
            this.singlebackBTN.UseVisualStyleBackColor = true;
            this.singlebackBTN.Click += new System.EventHandler(this.singlebackBTN_Click);
            // 
            // singleforwardBTN
            // 
            this.singleforwardBTN.Location = new System.Drawing.Point(369, 239);
            this.singleforwardBTN.Name = "singleforwardBTN";
            this.singleforwardBTN.Size = new System.Drawing.Size(75, 23);
            this.singleforwardBTN.TabIndex = 19;
            this.singleforwardBTN.Text = ">>";
            this.singleforwardBTN.UseVisualStyleBackColor = true;
            this.singleforwardBTN.Click += new System.EventHandler(this.singleforwardBTN_Click);
            // 
            // fullforwardBTN
            // 
            this.fullforwardBTN.Location = new System.Drawing.Point(481, 239);
            this.fullforwardBTN.Name = "fullforwardBTN";
            this.fullforwardBTN.Size = new System.Drawing.Size(75, 23);
            this.fullforwardBTN.TabIndex = 20;
            this.fullforwardBTN.Text = ">>|";
            this.fullforwardBTN.UseVisualStyleBackColor = true;
            this.fullforwardBTN.Click += new System.EventHandler(this.fullforwardBTN_Click);
            // 
            // id_error
            // 
            this.id_error.ContainerControl = this;
            // 
            // name_error
            // 
            this.name_error.ContainerControl = this;
            // 
            // imageNAMETXT
            // 
            this.imageNAMETXT.Location = new System.Drawing.Point(476, 197);
            this.imageNAMETXT.Name = "imageNAMETXT";
            this.imageNAMETXT.Size = new System.Drawing.Size(100, 22);
            this.imageNAMETXT.TabIndex = 21;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(732, 374);
            this.Controls.Add(this.imageNAMETXT);
            this.Controls.Add(this.fullforwardBTN);
            this.Controls.Add(this.singleforwardBTN);
            this.Controls.Add(this.singlebackBTN);
            this.Controls.Add(this.fullbackBTN);
            this.Controls.Add(this.exitBTN);
            this.Controls.Add(this.deleteBTN);
            this.Controls.Add(this.updateBTN);
            this.Controls.Add(this.searchBTN);
            this.Controls.Add(this.insertBTN);
            this.Controls.Add(this.newBTN);
            this.Controls.Add(this.browseBTN);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.feesTXT);
            this.Controls.Add(this.courceTXT);
            this.Controls.Add(this.nameTXT);
            this.Controls.Add(this.stuno);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lb2);
            this.Controls.Add(this.lb1);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.id_error)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.name_error)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lb1;
        private System.Windows.Forms.Label lb2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox stuno;
        private System.Windows.Forms.TextBox nameTXT;
        private System.Windows.Forms.TextBox courceTXT;
        private System.Windows.Forms.TextBox feesTXT;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button browseBTN;
        private System.Windows.Forms.Button newBTN;
        private System.Windows.Forms.Button insertBTN;
        private System.Windows.Forms.Button searchBTN;
        private System.Windows.Forms.Button updateBTN;
        private System.Windows.Forms.Button deleteBTN;
        private System.Windows.Forms.Button exitBTN;
        private System.Windows.Forms.Button fullbackBTN;
        private System.Windows.Forms.Button singlebackBTN;
        private System.Windows.Forms.Button singleforwardBTN;
        private System.Windows.Forms.Button fullforwardBTN;
        private System.Windows.Forms.ErrorProvider id_error;
        private System.Windows.Forms.ErrorProvider name_error;
        private System.Windows.Forms.TextBox imageNAMETXT;
    }
}

