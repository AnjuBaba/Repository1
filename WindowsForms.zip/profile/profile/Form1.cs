﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace profile
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        SqlConnection con;
        SqlCommand cmd;
        SqlDataReader rdr;
        FileStream fs;
        BinaryReader br;
         
        private void exitBTN_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            con = new SqlConnection("server=BLT210\\SQLEXPRESS; Database = profile; Integrated Security=true ");
            con.Open();
            
        }

        private void newBTN_Click(object sender, EventArgs e)
        {
            stuno.Text = "";
            nameTXT.Text = "";
            courceTXT.Text = "";
            feesTXT.Text = "";
        }

        private void insertBTN_Click(object sender, EventArgs e)
        {
            if (stuno.Text == "")
            {
                MessageBox.Show("Please Enter Student ID", "Required");

            }

            if (string.IsNullOrWhiteSpace(stuno.Text))
            {

                stuno.Focus();
                id_error.SetError(stuno, "StudentId Required!");
            }
            else
            {

                id_error.SetError(stuno, "");
            }

            if (string.IsNullOrWhiteSpace(nameTXT.Text))
            {
                nameTXT.Focus();
                name_error.SetError(nameTXT, "Student Name Required!");
            }
            else
            {
                name_error.SetError(nameTXT, "");
            }

            string FileName = imageNAMETXT.Text;
            byte[] ImageData;
            fs = new FileStream(FileName, FileMode.Open, FileAccess.Read);
            br = new BinaryReader(fs);
            ImageData = br.ReadBytes((int)fs.Length);
            br.Close();
            fs.Close();


            string query;
            query = "INSERT into student_profile VALUES ('" + stuno.Text + "','" + nameTXT.Text + "','" + courceTXT.Text + "','" + feesTXT.Text + "','"+ ImageData + "')";

            cmd = new SqlCommand(query, con);
            cmd.ExecuteNonQuery();
            MessageBox.Show("Inserted", "Done");
            stuno.Text = "";
            nameTXT.Text = "";
            courceTXT.Text = "";
            feesTXT.Text = "";
        }

        private void deleteBTN_Click(object sender, EventArgs e)
        {
            string query;
            query = "DELETE FROM student_profile WHERE student_id = '"+ stuno.Text + "'  ";

            cmd = new SqlCommand(query, con);
            cmd.ExecuteNonQuery();
            MessageBox.Show("Deleted Successfully", "Done");
            stuno.Text = "";         
        }

        private void updateBTN_Click(object sender, EventArgs e)
        {
            string query;
            query = "UPDATE student_profile set student_name='" + nameTXT.Text + "',course='" + courceTXT.Text + "',course_fee='" + feesTXT.Text + "' WHERE student_id ='" + stuno.Text + "' ";

            cmd = new SqlCommand(query, con);
            cmd.ExecuteNonQuery();


            MessageBox.Show("Updated Success", "Done");
            stuno.Text = "";
            nameTXT.Text = "";
            courceTXT.Text = "";
            feesTXT.Text = "";
        }

        private void searchBTN_Click(object sender, EventArgs e)
        {
            string query;
            query = "SELECT * FROM student_profile where student_id = '"+ stuno.Text +"'  ";

            cmd = new SqlCommand(query, con);
           
            try 
            {
                rdr = cmd.ExecuteReader();
                if (rdr.Read())
                {
                    stuno.Text = rdr["student_id"].ToString();
                    nameTXT.Text = rdr[1].ToString();
                    courceTXT.Text = rdr[2].ToString();
                    feesTXT.Text = rdr[3].ToString();           
                }
                rdr.Close();

                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataSet ds=new DataSet();

                da.Fill(ds);

                if(ds.Tables[0].Rows.Count > 0 )
                {
                    MemoryStream ms = new MemoryStream((byte[])ds.Tables[0].Rows[0]["photo"]);

                    pictureBox1.Image = new Bitmap(ms);
                }
                else
                {
                    MessageBox.Show("Record NOt Match");
                }
                rdr.Close();

            }
            catch(Exception exe)
            {
                MessageBox.Show(exe.Message);
            }

        }

        private void fullbackBTN_Click(object sender, EventArgs e)
        {
            string query;
            query = "SELECT * FROM student_profile   ";

            cmd = new SqlCommand(query, con);

            try
            {
                rdr = cmd.ExecuteReader();
                if (rdr.Read())
                {
                    stuno.Text = rdr[0].ToString();
                    nameTXT.Text = rdr[1].ToString();
                    courceTXT.Text = rdr[2].ToString();
                    feesTXT.Text = rdr[3].ToString();
                }
                else
                {
                    MessageBox.Show("Record NOt Match");
                }
                rdr.Close();
            }
            catch (Exception)
            {
                MessageBox.Show("Invald");
            }
        }

        private void fullforwardBTN_Click(object sender, EventArgs e)
        {
            string query;
            query = "SELECT * FROM student_profile WHERE student_id=(SELECT MAX(student_id) FROM student_profile  )  ";

            cmd = new SqlCommand(query, con);

            try
            {
                rdr = cmd.ExecuteReader();
                if (rdr.Read())
                {
                    stuno.Text = rdr[0].ToString();
                    nameTXT.Text = rdr[1].ToString();
                    courceTXT.Text = rdr[2].ToString();
                    feesTXT.Text = rdr[3].ToString();
                }
                else
                {
                    MessageBox.Show("Record NOt Match");
                }
                rdr.Close();
            }
            catch (Exception)
            {
                MessageBox.Show("Invald");
            }
        }

        private void singlebackBTN_Click(object sender, EventArgs e)
        {
            if (stuno.Text != "")
            {
                string query;
                query = "SELECT * FROM student_profile WHERE student_id < (SELECT student_id FROM student_profile where student_id='"+ stuno.Text +"' ) ORDER BY student_id DESC  ";

                cmd = new SqlCommand(query, con);

                try
                {
                    rdr = cmd.ExecuteReader();
                    if (rdr.Read())
                    {
                        stuno.Text = rdr[0].ToString();
                        nameTXT.Text = rdr[1].ToString();
                        courceTXT.Text = rdr[2].ToString();
                        feesTXT.Text = rdr[3].ToString();
                    }
                    else
                    {
                        MessageBox.Show("Record NOt Match");
                    }
                    rdr.Close();
                }
                catch (Exception)
                {
                    MessageBox.Show("Invald");
                }
            }
        }

        private void singleforwardBTN_Click(object sender, EventArgs e)
        {
            if (stuno.Text != "")
            {
                string query;
                query = "SELECT * FROM student_profile WHERE student_id > (SELECT student_id FROM student_profile where student_id='"+ stuno.Text +"' )  ";

                cmd = new SqlCommand(query, con);

                try
                {
                    rdr = cmd.ExecuteReader();
                    if (rdr.Read())
                    {
                        stuno.Text = rdr[0].ToString();
                        nameTXT.Text = rdr[1].ToString();
                        courceTXT.Text = rdr[2].ToString();
                        feesTXT.Text = rdr[3].ToString();
                    }
                    else
                    {
                        MessageBox.Show("Record NOt Match");
                    }
                    rdr.Close();
                }
                catch (Exception)
                {
                    MessageBox.Show("Invald");
                }
            }
        }

        private void browseBTN_Click(object sender, EventArgs e)
        {
            OpenFileDialog opnfd = new OpenFileDialog();
            opnfd.Filter = "Image Files (*.jpg;*.jpeg;.*.gif;)|*.jpg;*.jpeg;.*.gif";
            if(opnfd.ShowDialog() == DialogResult.OK)
            {
                imageNAMETXT.Text = opnfd.FileName;
                pictureBox1.Image = new Bitmap(opnfd.FileName);
            }
        }
    }
}
