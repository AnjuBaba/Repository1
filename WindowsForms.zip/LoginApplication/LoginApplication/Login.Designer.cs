﻿namespace LoginApplication
{
    partial class Login
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.LblUID = new System.Windows.Forms.Label();
            this.LblPWD = new System.Windows.Forms.Label();
            this.TxtUID = new System.Windows.Forms.TextBox();
            this.TxtPWD = new System.Windows.Forms.TextBox();
            this.BtnLogin = new System.Windows.Forms.Button();
            this.BtnOut = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // LblUID
            // 
            this.LblUID.AutoSize = true;
            this.LblUID.Location = new System.Drawing.Point(31, 32);
            this.LblUID.Name = "LblUID";
            this.LblUID.Size = new System.Drawing.Size(66, 16);
            this.LblUID.TabIndex = 0;
            this.LblUID.Text = "User ID:";
            // 
            // LblPWD
            // 
            this.LblPWD.AutoSize = true;
            this.LblPWD.Location = new System.Drawing.Point(31, 72);
            this.LblPWD.Name = "LblPWD";
            this.LblPWD.Size = new System.Drawing.Size(83, 16);
            this.LblPWD.TabIndex = 1;
            this.LblPWD.Text = "Password:";
            // 
            // TxtUID
            // 
            this.TxtUID.Location = new System.Drawing.Point(129, 29);
            this.TxtUID.MaxLength = 10;
            this.TxtUID.Name = "TxtUID";
            this.TxtUID.Size = new System.Drawing.Size(219, 23);
            this.TxtUID.TabIndex = 2;
            // 
            // TxtPWD
            // 
            this.TxtPWD.Location = new System.Drawing.Point(129, 72);
            this.TxtPWD.MaxLength = 10;
            this.TxtPWD.Name = "TxtPWD";
            this.TxtPWD.PasswordChar = '*';
            this.TxtPWD.Size = new System.Drawing.Size(219, 23);
            this.TxtPWD.TabIndex = 3;
            // 
            // BtnLogin
            // 
            this.BtnLogin.Location = new System.Drawing.Point(34, 116);
            this.BtnLogin.Name = "BtnLogin";
            this.BtnLogin.Size = new System.Drawing.Size(137, 39);
            this.BtnLogin.TabIndex = 4;
            this.BtnLogin.Text = "Login";
            this.BtnLogin.UseVisualStyleBackColor = true;
            this.BtnLogin.Click += new System.EventHandler(this.BtnLogin_Click);
            // 
            // BtnOut
            // 
            this.BtnOut.Location = new System.Drawing.Point(211, 116);
            this.BtnOut.Name = "BtnOut";
            this.BtnOut.Size = new System.Drawing.Size(137, 39);
            this.BtnOut.TabIndex = 5;
            this.BtnOut.Text = "Logout";
            this.BtnOut.UseVisualStyleBackColor = true;
            // 
            // Login
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(379, 184);
            this.Controls.Add(this.BtnOut);
            this.Controls.Add(this.BtnLogin);
            this.Controls.Add(this.TxtPWD);
            this.Controls.Add(this.TxtUID);
            this.Controls.Add(this.LblPWD);
            this.Controls.Add(this.LblUID);
            this.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Login";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Login Application";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label LblUID;
        private System.Windows.Forms.Label LblPWD;
        private System.Windows.Forms.TextBox TxtUID;
        private System.Windows.Forms.TextBox TxtPWD;
        private System.Windows.Forms.Button BtnLogin;
        private System.Windows.Forms.Button BtnOut;
    }
}

